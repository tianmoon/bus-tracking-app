import { useState } from "react";
import { DriverSidebar } from "./driver-dashboard/DriverSidebar";
import { DriverHeader } from "./driver-dashboard/DriverHeader";
import { DriverDashboardPage } from "./driver-dashboard/pages/DriverDashboardPage";
import { DriverSchedulePage } from "./driver-dashboard/pages/DriverSchedulePage";
import { DriverStudentListPage } from "./driver-dashboard/pages/DriverStudentListPage";
import { IncidentReportPage } from "./driver-dashboard/pages/IncidentReportPage";
import { DriverMessagesPage } from "./driver-dashboard/pages/DriverMessagesPage";

export type DriverPageType =
  | "dashboard"
  | "schedule"
  | "students"
  | "incident"
  | "messages";

export function DriverDashboard() {
  const [currentPage, setCurrentPage] = useState<DriverPageType>("dashboard");
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);

  const renderPage = () => {
    switch (currentPage) {
      case "dashboard":
        return <DriverDashboardPage />;
      case "schedule":
        return <DriverSchedulePage />;
      case "students":
        return <DriverStudentListPage />;
      case "incident":
        return <IncidentReportPage />;
      case "messages":
        return <DriverMessagesPage />;
      default:
        return <DriverDashboardPage />;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Sidebar */}
      <DriverSidebar
        currentPage={currentPage}
        onPageChange={setCurrentPage}
        collapsed={sidebarCollapsed}
        onToggleCollapse={() => setSidebarCollapsed(!sidebarCollapsed)}
      />

      {/* Main Content */}
      <div
        className={`transition-all duration-300 ${
          sidebarCollapsed ? "ml-20" : "ml-64"
        }`}
      >
        {/* Header */}
        <DriverHeader />

        {/* Page Content */}
        <main className="p-6">{renderPage()}</main>
      </div>
    </div>
  );
}
