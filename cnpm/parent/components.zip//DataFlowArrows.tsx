import { ArrowRight, ArrowLeftRight } from "lucide-react";

export function DataFlowArrows() {
  return (
    <div className="hidden lg:block absolute inset-0 pointer-events-none">
      {/* Admin → Driver: Assignment */}
      <div className="absolute left-[33%] top-[25%] transform -translate-x-1/2">
        <div className="flex items-center gap-2 bg-blue-500 text-white px-3 py-1 rounded-full shadow-lg text-xs">
          <span>Assignments</span>
          <ArrowRight className="w-4 h-4" />
        </div>
      </div>

      {/* Admin → Driver: Messages */}
      <div className="absolute left-[33%] top-[55%] transform -translate-x-1/2">
        <div className="flex items-center gap-2 bg-purple-500 text-white px-3 py-1 rounded-full shadow-lg text-xs">
          <span>Messages</span>
          <ArrowRight className="w-4 h-4" />
        </div>
      </div>

      {/* Driver → Parent: Location Updates */}
      <div className="absolute left-[66%] top-[35%] transform -translate-x-1/2">
        <div className="flex items-center gap-2 bg-green-500 text-white px-3 py-1 rounded-full shadow-lg text-xs">
          <span>Location Updates</span>
          <ArrowRight className="w-4 h-4" />
        </div>
      </div>

      {/* Driver → Parent: Notifications */}
      <div className="absolute left-[66%] top-[45%] transform -translate-x-1/2">
        <div className="flex items-center gap-2 bg-green-500 text-white px-3 py-1 rounded-full shadow-lg text-xs">
          <span>Notifications</span>
          <ArrowRight className="w-4 h-4" />
        </div>
      </div>

      {/* Driver → Admin: Alerts */}
      <div className="absolute left-[33%] top-[60%] transform -translate-x-1/2 rotate-180">
        <div className="flex items-center gap-2 bg-orange-500 text-white px-3 py-1 rounded-full shadow-lg text-xs rotate-180">
          <span>Alerts</span>
          <ArrowRight className="w-4 h-4" />
        </div>
      </div>

      {/* Parent → Admin: Feedback */}
      <div className="absolute left-[50%] top-[75%] transform -translate-x-1/2">
        <div className="flex items-center gap-2 bg-purple-500 text-white px-3 py-1 rounded-full shadow-lg text-xs">
          <ArrowLeftRight className="w-4 h-4" />
          <span>Feedback/Messages</span>
        </div>
      </div>

      {/* Admin → Parent: Alerts from system */}
      <div className="absolute left-[66%] top-[60%] transform -translate-x-1/2">
        <div className="flex items-center gap-2 bg-orange-500 text-white px-3 py-1 rounded-full shadow-lg text-xs">
          <span>System Alerts</span>
          <ArrowRight className="w-4 h-4" />
        </div>
      </div>
    </div>
  );
}
