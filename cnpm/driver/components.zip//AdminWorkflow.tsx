import {
  UserCog,
  LayoutDashboard,
  Bus,
  Users,
  MapPin,
  Calendar,
  Map,
  AlertTriangle,
  MessageSquare,
  BarChart3,
  LogIn,
} from "lucide-react";
import { WorkflowStep } from "./WorkflowStep";

export function AdminWorkflow() {
  return (
    <div className="bg-gradient-to-b from-blue-50 to-blue-100 rounded-xl p-6 border-2 border-blue-300 shadow-lg min-h-full">
      {/* Header */}
      <div className="flex items-center gap-3 mb-6 pb-4 border-b-2 border-blue-300">
        <div className="w-12 h-12 rounded-full bg-blue-600 flex items-center justify-center">
          <UserCog className="w-6 h-6 text-white" />
        </div>
        <div>
          <h2 className="text-blue-900">Admin</h2>
          <p className="text-sm text-blue-700">Quản lý</p>
        </div>
      </div>

      {/* Workflow Steps */}
      <div className="space-y-4">
        <WorkflowStep
          icon={<LogIn className="w-5 h-5" />}
          title="Login"
          description="System authentication"
          color="blue"
          type="start"
        />

        <WorkflowStep
          icon={<LayoutDashboard className="w-5 h-5" />}
          title="Dashboard View"
          description="Overview of all operations"
          color="blue"
        />

        <WorkflowStep
          icon={<Bus className="w-5 h-5" />}
          title="Manage Resources"
          description="Buses, drivers, students, routes"
          color="blue"
        />

        <WorkflowStep
          icon={<Calendar className="w-5 h-5" />}
          title="Create Schedules"
          description="Weekly/monthly planning"
          color="blue"
        />

        <WorkflowStep
          icon={<Users className="w-5 h-5" />}
          title="Assign Resources"
          description="Driver + Bus → Route"
          color="blue"
        />

        <WorkflowStep
          icon={<Map className="w-5 h-5" />}
          title="Monitor Live Tracking"
          description="Real-time bus locations"
          color="blue"
        />

        <WorkflowStep
          icon={<AlertTriangle className="w-5 h-5" />}
          title="Receive Alerts"
          description="Delays, incidents, off-route"
          color="orange"
        />

        <WorkflowStep
          icon={<MessageSquare className="w-5 h-5" />}
          title="System Messaging"
          description="Chat with drivers/parents"
          color="purple"
        />

        <WorkflowStep
          icon={<BarChart3 className="w-5 h-5" />}
          title="Generate Reports"
          description="Performance & analytics"
          color="blue"
          type="end"
        />
      </div>
    </div>
  );
}
