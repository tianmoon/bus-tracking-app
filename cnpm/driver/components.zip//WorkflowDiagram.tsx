import { AdminWorkflow } from "./AdminWorkflow";
import { DriverWorkflow } from "./DriverWorkflow";
import { ParentWorkflow } from "./ParentWorkflow";
import { DataFlowArrows } from "./DataFlowArrows";

export function WorkflowDiagram() {
  return (
    <div className="w-full py-12 px-6">
      {/* Header */}
      <div className="max-w-7xl mx-auto mb-12 text-center">
        <h1 className="text-indigo-900 mb-3">
          Smart School Bus Tracking System – SSB 1.0 Workflow
        </h1>
        <p className="text-gray-600 text-lg">
          Interaction Flow between Admin, Driver, and Parent
        </p>
      </div>

      {/* Legend */}
      <div className="max-w-7xl mx-auto mb-8 flex items-center justify-center gap-6 flex-wrap">
        <div className="flex items-center gap-2">
          <div className="w-4 h-4 rounded-full bg-blue-500"></div>
          <span className="text-sm text-gray-700">Action</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-4 h-4 rounded-full bg-green-500"></div>
          <span className="text-sm text-gray-700">Notification</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-4 h-4 rounded-full bg-orange-500"></div>
          <span className="text-sm text-gray-700">Alert</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-4 h-4 rounded-full bg-purple-500"></div>
          <span className="text-sm text-gray-700">Communication</span>
        </div>
      </div>

      {/* Swimlanes Container */}
      <div className="max-w-7xl mx-auto relative">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 relative">
          {/* Admin Swimlane */}
          <div className="relative">
            <AdminWorkflow />
          </div>

          {/* Driver Swimlane */}
          <div className="relative">
            <DriverWorkflow />
          </div>

          {/* Parent Swimlane */}
          <div className="relative">
            <ParentWorkflow />
          </div>
        </div>

        {/* Data Flow Arrows - Desktop Only */}
        <DataFlowArrows />
      </div>

      {/* System Behaviors Footer */}
      <div className="max-w-7xl mx-auto mt-12 bg-white rounded-lg shadow-lg p-8 border-2 border-indigo-100">
        <h3 className="text-indigo-900 mb-4">System Behaviors</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="flex items-start gap-3">
            <div className="w-2 h-2 rounded-full bg-indigo-500 mt-2"></div>
            <p className="text-gray-700">
              Real-time updates powered by GPS tracking and push notifications
            </p>
          </div>
          <div className="flex items-start gap-3">
            <div className="w-2 h-2 rounded-full bg-indigo-500 mt-2"></div>
            <p className="text-gray-700">
              Communication between users through in-app messaging
            </p>
          </div>
          <div className="flex items-start gap-3">
            <div className="w-2 h-2 rounded-full bg-indigo-500 mt-2"></div>
            <p className="text-gray-700">
              Every alert or update from driver triggers a parent notification
            </p>
          </div>
          <div className="flex items-start gap-3">
            <div className="w-2 h-2 rounded-full bg-indigo-500 mt-2"></div>
            <p className="text-gray-700">
              Admin can view all events in the dashboard timeline
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
