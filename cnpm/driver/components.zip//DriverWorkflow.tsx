import {
  UserCircle,
  LogIn,
  Calendar,
  MapPin,
  CheckCircle,
  UserCheck,
  CheckSquare,
  AlertOctagon,
  FileText,
} from "lucide-react";
import { WorkflowStep } from "./WorkflowStep";

export function DriverWorkflow() {
  return (
    <div className="bg-gradient-to-b from-green-50 to-green-100 rounded-xl p-6 border-2 border-green-300 shadow-lg min-h-full">
      {/* Header */}
      <div className="flex items-center gap-3 mb-6 pb-4 border-b-2 border-green-300">
        <div className="w-12 h-12 rounded-full bg-green-600 flex items-center justify-center">
          <UserCircle className="w-6 h-6 text-white" />
        </div>
        <div>
          <h2 className="text-green-900">Driver</h2>
          <p className="text-sm text-green-700">Tài xế</p>
        </div>
      </div>

      {/* Workflow Steps */}
      <div className="space-y-4">
        <WorkflowStep
          icon={<LogIn className="w-5 h-5" />}
          title="Login"
          description="System authentication"
          color="green"
          type="start"
        />

        <WorkflowStep
          icon={<Calendar className="w-5 h-5" />}
          title="View Daily Schedule"
          description="Route & student list"
          color="green"
        />

        <WorkflowStep
          icon={<MapPin className="w-5 h-5" />}
          title="Pickup Points"
          description="List of stops with students"
          color="green"
        />

        <WorkflowStep
          icon={<CheckCircle className="w-5 h-5" />}
          title="Mark 'Arrived'"
          description="At each stop"
          color="green"
          badge="→ Notifies Parents"
        />

        <WorkflowStep
          icon={<UserCheck className="w-5 h-5" />}
          title="Mark 'Picked Up'"
          description="Student boarded"
          color="green"
          badge="→ Notifies Parents"
        />

        <WorkflowStep
          icon={<CheckSquare className="w-5 h-5" />}
          title="Mark 'Completed'"
          description="Trip finished"
          color="green"
        />

        <WorkflowStep
          icon={<AlertOctagon className="w-5 h-5" />}
          title="Send SOS/Alert"
          description="Emergency or incident"
          color="orange"
          badge="→ Alerts Admin & Parents"
        />

        <WorkflowStep
          icon={<FileText className="w-5 h-5" />}
          title="Daily Summary"
          description="Submit trip report"
          color="green"
          type="end"
        />
      </div>
    </div>
  );
}
