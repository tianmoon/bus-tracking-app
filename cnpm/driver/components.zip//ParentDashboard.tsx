import { useState } from "react";
import { ParentSidebar } from "./parent-dashboard/ParentSidebar";
import { ParentHeader } from "./parent-dashboard/ParentHeader";
import { ParentDashboardPage } from "./parent-dashboard/pages/ParentDashboardPage";
import { MyChildPage } from "./parent-dashboard/pages/MyChildPage";
import { BusLocationPage } from "./parent-dashboard/pages/BusLocationPage";
import { NotificationsPage } from "./parent-dashboard/pages/NotificationsPage";

export type ParentPageType = "dashboard" | "child" | "location" | "notifications";

export function ParentDashboard() {
  const [currentPage, setCurrentPage] = useState<ParentPageType>("dashboard");
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);

  const renderPage = () => {
    switch (currentPage) {
      case "dashboard":
        return <ParentDashboardPage />;
      case "child":
        return <MyChildPage />;
      case "location":
        return <BusLocationPage />;
      case "notifications":
        return <NotificationsPage />;
      default:
        return <ParentDashboardPage />;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Sidebar */}
      <ParentSidebar
        currentPage={currentPage}
        onPageChange={setCurrentPage}
        collapsed={sidebarCollapsed}
        onToggleCollapse={() => setSidebarCollapsed(!sidebarCollapsed)}
      />

      {/* Main Content */}
      <div
        className={`transition-all duration-300 ${
          sidebarCollapsed ? "ml-20" : "ml-64"
        }`}
      >
        {/* Header */}
        <ParentHeader />

        {/* Page Content */}
        <main className="p-6">{renderPage()}</main>
      </div>
    </div>
  );
}
