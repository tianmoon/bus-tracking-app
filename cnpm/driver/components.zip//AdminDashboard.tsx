import { useState } from "react";
import { Sidebar } from "./dashboard/Sidebar";
import { Header } from "./dashboard/Header";
import { DashboardPage } from "./dashboard/pages/DashboardPage";
import { StudentsPage } from "./dashboard/pages/StudentsPage";
import { DriversPage } from "./dashboard/pages/DriversPage";
import { BusesPage } from "./dashboard/pages/BusesPage";
import { RoutesPage } from "./dashboard/pages/RoutesPage";
import { SchedulePage } from "./dashboard/pages/SchedulePage";
import { GPSTrackingPage } from "./dashboard/pages/GPSTrackingPage";
import { AlertsMessagesPage } from "./dashboard/pages/AlertsMessagesPage";

export type PageType =
  | "dashboard"
  | "students"
  | "drivers"
  | "buses"
  | "routes"
  | "schedule"
  | "gps"
  | "alerts";

export function AdminDashboard() {
  const [currentPage, setCurrentPage] = useState<PageType>("dashboard");
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);

  const renderPage = () => {
    switch (currentPage) {
      case "dashboard":
        return <DashboardPage />;
      case "students":
        return <StudentsPage />;
      case "drivers":
        return <DriversPage />;
      case "buses":
        return <BusesPage />;
      case "routes":
        return <RoutesPage />;
      case "schedule":
        return <SchedulePage />;
      case "gps":
        return <GPSTrackingPage />;
      case "alerts":
        return <AlertsMessagesPage />;
      default:
        return <DashboardPage />;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Sidebar */}
      <Sidebar
        currentPage={currentPage}
        onPageChange={setCurrentPage}
        collapsed={sidebarCollapsed}
        onToggleCollapse={() => setSidebarCollapsed(!sidebarCollapsed)}
      />

      {/* Main Content */}
      <div
        className={`transition-all duration-300 ${
          sidebarCollapsed ? "ml-20" : "ml-64"
        }`}
      >
        {/* Header */}
        <Header />

        {/* Page Content */}
        <main className="p-6">{renderPage()}</main>
      </div>
    </div>
  );
}
