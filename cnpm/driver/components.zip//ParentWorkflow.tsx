import {
  User,
  LogIn,
  Users,
  Map,
  Bell,
  CheckCircle,
  AlertTriangle,
  MessageCircle,
  History,
} from "lucide-react";
import { WorkflowStep } from "./WorkflowStep";

export function ParentWorkflow() {
  return (
    <div className="bg-gradient-to-b from-purple-50 to-purple-100 rounded-xl p-6 border-2 border-purple-300 shadow-lg min-h-full">
      {/* Header */}
      <div className="flex items-center gap-3 mb-6 pb-4 border-b-2 border-purple-300">
        <div className="w-12 h-12 rounded-full bg-purple-600 flex items-center justify-center">
          <User className="w-6 h-6 text-white" />
        </div>
        <div>
          <h2 className="text-purple-900">Parent</h2>
          <p className="text-sm text-purple-700">Phụ huynh</p>
        </div>
      </div>

      {/* Workflow Steps */}
      <div className="space-y-4">
        <WorkflowStep
          icon={<LogIn className="w-5 h-5" />}
          title="Login"
          description="System authentication"
          color="purple"
          type="start"
        />

        <WorkflowStep
          icon={<Users className="w-5 h-5" />}
          title="View Student Info"
          description="Linked student details"
          color="purple"
        />

        <WorkflowStep
          icon={<Map className="w-5 h-5" />}
          title="Track Bus Live"
          description="Real-time map with ETA"
          color="purple"
        />

        <WorkflowStep
          icon={<Bell className="w-5 h-5" />}
          title="Receive Notifications"
          description="Bus near pickup stop"
          color="green"
          badge="← From Driver"
        />

        <WorkflowStep
          icon={<CheckCircle className="w-5 h-5" />}
          title="Send Acknowledgment"
          description="Confirm boarding/alighting"
          color="purple"
        />

        <WorkflowStep
          icon={<AlertTriangle className="w-5 h-5" />}
          title="Receive Alerts"
          description="Delays or SOS events"
          color="orange"
          badge="← From Driver/Admin"
        />

        <WorkflowStep
          icon={<History className="w-5 h-5" />}
          title="View Trip History"
          description="Past journeys"
          color="purple"
        />

        <WorkflowStep
          icon={<MessageCircle className="w-5 h-5" />}
          title="Contact Admin"
          description="Feedback or support"
          color="purple"
          type="end"
        />
      </div>
    </div>
  );
}
