import { ReactNode } from "react";

interface WorkflowStepProps {
  icon: ReactNode;
  title: string;
  description: string;
  color: "blue" | "green" | "purple" | "orange";
  type?: "start" | "end" | "normal";
  badge?: string;
}

const colorClasses = {
  blue: {
    bg: "bg-blue-500",
    border: "border-blue-500",
    text: "text-blue-900",
    light: "bg-blue-50",
    icon: "text-blue-600",
  },
  green: {
    bg: "bg-green-500",
    border: "border-green-500",
    text: "text-green-900",
    light: "bg-green-50",
    icon: "text-green-600",
  },
  purple: {
    bg: "bg-purple-500",
    border: "border-purple-500",
    text: "text-purple-900",
    light: "bg-purple-50",
    icon: "text-purple-600",
  },
  orange: {
    bg: "bg-orange-500",
    border: "border-orange-500",
    text: "text-orange-900",
    light: "bg-orange-50",
    icon: "text-orange-600",
  },
};

export function WorkflowStep({
  icon,
  title,
  description,
  color,
  type = "normal",
  badge,
}: WorkflowStepProps) {
  const colors = colorClasses[color];
  const isStart = type === "start";
  const isEnd = type === "end";

  return (
    <div className="relative">
      {/* Connector Line */}
      {!isStart && (
        <div
          className={`absolute left-6 -top-4 w-0.5 h-4 ${colors.bg} opacity-50`}
        ></div>
      )}

      {/* Step Card */}
      <div
        className={`relative bg-white rounded-lg p-4 border-2 ${colors.border} shadow-md hover:shadow-lg transition-shadow ${
          isStart || isEnd ? "ring-2 ring-offset-2 ring-" + color + "-400" : ""
        }`}
      >
        <div className="flex items-start gap-3">
          {/* Icon */}
          <div
            className={`w-10 h-10 rounded-full ${colors.bg} flex items-center justify-center flex-shrink-0 text-white`}
          >
            {icon}
          </div>

          {/* Content */}
          <div className="flex-1 min-w-0">
            <h4 className={`${colors.text} mb-1`}>{title}</h4>
            <p className="text-xs text-gray-600 leading-snug">{description}</p>

            {/* Badge for notifications */}
            {badge && (
              <div className="mt-2">
                <span className="inline-block text-xs bg-yellow-100 text-yellow-800 px-2 py-1 rounded">
                  {badge}
                </span>
              </div>
            )}
          </div>

          {/* Start/End indicator */}
          {isStart && (
            <div className="flex-shrink-0">
              <span className="text-xs bg-green-500 text-white px-2 py-1 rounded">
                Start
              </span>
            </div>
          )}
          {isEnd && (
            <div className="flex-shrink-0">
              <span className="text-xs bg-red-500 text-white px-2 py-1 rounded">
                End
              </span>
            </div>
          )}
        </div>
      </div>

      {/* Connector Line to next */}
      {!isEnd && (
        <div
          className={`absolute left-6 bottom-0 w-0.5 h-4 ${colors.bg} opacity-50 translate-y-full`}
        ></div>
      )}
    </div>
  );
}
